<?php

return [
    'setup' => 'In the Enot control panel, enter the notification URL (WebHook) :notification <br>You can enter the success and failure URLs respectively :success | :failure',

    'keys' => 'Enot',

    'desc' => 'Payment Description',

    'private-key-2' => 'Private Key 2',

    'color' => 'Logo Color',
];
