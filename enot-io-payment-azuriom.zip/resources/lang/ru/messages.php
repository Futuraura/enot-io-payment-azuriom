<?php

return [
    'setup' => 'В панели управления Enot введите URL оповещения (WebHook) :notification <br>Можете ввести URL успеха и неуспеха соответвенно :success | :failure',

    'keys' => 'Enot',

    'desc' => 'Описание платежа',

    'private-key-2' => 'Приватный ключ 2',

    'color' => 'Цвет логотипа',
];
